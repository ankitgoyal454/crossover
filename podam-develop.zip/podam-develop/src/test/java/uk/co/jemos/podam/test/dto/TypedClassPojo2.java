package uk.co.jemos.podam.test.dto;


/**
 * Pojo derived from typed class
 * 
 * @author daivanov
 *
 */
public class TypedClassPojo2 extends TypedClassPojo<String> {
}


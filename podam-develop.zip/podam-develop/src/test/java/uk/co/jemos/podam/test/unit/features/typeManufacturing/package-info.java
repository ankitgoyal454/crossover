/**
 * Contains tests for Spring integration type manufacturing.
 *
 * Created by tedonema on 28/06/2015.
 *
 * @since 6.0.0.RELEASE
 */
package uk.co.jemos.podam.test.unit.features.typeManufacturing;